int led_red = 13;
int led_blue = 12;

int bnt_red = 10;
int bnt_blue; = 11;

int bnt_state_red = 0;
int bnt_state_blue = 0;

void setup() {  
  // put your setup code here, to run once:
  pinMode(led_red, OUTPUT);
  pinMode(led_blue, OUTPUT);
  pinMode(bnt_red INPUT);
  pinMode(bnt_blue, INPUT);

}

void loop() {
  // put your main code here, to run repeatedly:
  bnt_state_red = digitalRead(bnt_red);
  bnt_state_blue = digitalRead(bnt_blue);

  if (bnt_state_red == HIGH){
    digitalWrite(led_red, HIGH);
  }
  else{
    digitalWrite(led_red, LOW);
  }

  if (bnt_state_blue == HIGH){
    digitalWrite(led_blue, HIGH);
  }
  else{
    digitalWrite(led_blue. LOW);
  }
  
}
